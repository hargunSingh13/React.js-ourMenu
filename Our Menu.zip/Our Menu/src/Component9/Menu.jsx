import React, { useState } from 'react'
import data from '../menu.json';

const Menu = () => {
  const [type, setType] = useState("all");

  // console.log(data)
  console.log(type)
  return (
    <>
    <div>
    <div className='mb-5 pb-1'>
    <p className='text-red-600 text-4xl font-bold  text-center mt-5 mb-5'>Our Menu</p>
    </div>
    <div className='flex justify-center mt-5 '>
      <button className='btn mr-5 bg-red-600 text-white' onClick={()=> {setType("all")}}>all</button>
      <button className='btn mr-5 bg-red-600 text-white' onClick={()=> {setType("breakfast")}}>breakfast</button>
      <button className='btn mr-5 bg-red-600 text-white' onClick={()=>{setType("lunch")}}>lunch</button>
      <button className='btn bg-red-600 text-white' onClick={()=>{setType("dinner")}}>dinner</button>
    </div>
    
      <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 mt-5 ms-5 pe-5 ps-5 me-5 '>
      {data?.filter((i)=> i.category === `${type}` || i.set === `${type}`).map((i)=> (
        <div className="card card-side bg-base-100 shadow-xl">
       
        <>
        <figure>
          <img
            src={i.image}
            style={{width: "400px", height: "250px"}}
            alt="Food" />
        </figure>
        <div className="card-body">
          <h2 className="card-title">{i.name}</h2>
          <p>{i.description}</p>
          <div className="card-actions justify-end">
            <button className="btn btn-primary">${i.price}</button>
          </div>
        </div>
        </>
        
      </div>
      ) )}
      </div>
      
    
    </div>
    </>
  )
}

export default Menu